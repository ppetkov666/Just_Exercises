CREATE OR ALTER PROC spSearchEmployeesGoodDynamicSql
(@i_first_name NVARCHAR(100) = NULL,
@i_last_name NVARCHAR(100) = NULL,
@i_job_title NVARCHAR(100) = NULL,
@i_salary INT = null)
AS
BEGIN
	Declare @sql nvarchar(max);

	SET @sql = 'Select * from Employees Where 1=1'
	If @i_first_name is not null BEGIN
	SET @sql = @sql + ' AND Firstname=@first_name'
	END
	If @i_last_name is not null BEGIN
	SET @sql = @sql + ' AND Lastname=@last_name' 
	END
	If @i_job_title is not null BEGIN
	SET @sql = @sql + ' AND JobTitle=@job_title' 
	END
	If @i_salary is not null BEGIN
	SET @sql = @sql + ' AND Salary=cast(@salary as nvarchar)' 
	END
	EXECUTE sp_executesql @sql, N'@first_name nvarchar(100), @last_name nvarchar(100), @job_title nvarchar(100), @salary nvarchar(100)'
														, @first_name = @i_first_name, @last_name = @i_last_name, @job_title = @i_job_title, @salary = @i_salary
END
GO